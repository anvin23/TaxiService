import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-driver-adding-form',
  templateUrl: './driver-adding-form.component.html',
  styleUrls: ['./driver-adding-form.component.css']
})
export class DriverAddingFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
