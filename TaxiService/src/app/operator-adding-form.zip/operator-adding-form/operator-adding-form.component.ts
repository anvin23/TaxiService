import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operator-adding-form',
  templateUrl: './operator-adding-form.component.html',
  styleUrls: ['./operator-adding-form.component.css']
})
export class OperatorAddingFormComponent {

}
